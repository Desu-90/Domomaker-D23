const moviePage = (req, res) => res.render('movie');

module.exports = {
  moviePage,
};
